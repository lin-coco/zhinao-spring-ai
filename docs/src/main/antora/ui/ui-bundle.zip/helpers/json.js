'use strict'

module.exports = (data) => JSON.stringify(data, null, 2)
